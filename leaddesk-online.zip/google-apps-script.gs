const SHEET_NAME = "Leads";
const PIPELINE_SHEET_NAME = "Pipeline";

function doGet(e) {
  const action = e.parameter.action || "listLeads";
  if (action === "refreshPipeline") {
    updatePipelineSummary();
    return jsonOutput({ ok: true });
  }
  if (action !== "listLeads") {
    return jsonOutput({ error: "Unsupported action" });
  }

  const sheet = SpreadsheetApp.getActive().getSheetByName(SHEET_NAME);
  const values = sheet.getDataRange().getValues();
  const headers = values.shift();
  const leads = values
    .filter((row) => row.some(Boolean))
    .map((row) => rowToLead(headers, row));

  updatePipelineSummary();
  return jsonOutput({ leads });
}

function doPost(e) {
  const payload = JSON.parse(e.postData.contents || "{}");
  if (payload.action !== "updateLead" || !payload.lead) {
    return jsonOutput({ error: "Unsupported payload" });
  }

  const sheet = SpreadsheetApp.getActive().getSheetByName(SHEET_NAME);
  const values = sheet.getDataRange().getValues();
  const headers = values[0];
  const idIndex = headers.indexOf("id");
  const statusIndex = ensureColumn(sheet, headers, "status");
  const notesIndex = ensureColumn(sheet, headers, "notes");
  const updatedAtIndex = ensureColumn(sheet, headers, "updatedAt");
  const whatsappCountIndex = ensureColumn(sheet, headers, "whatsappCount");

  const targetRow = values.findIndex((row, index) => index > 0 && String(row[idIndex]) === String(payload.lead.id));
  if (targetRow === -1) {
    return jsonOutput({ error: "Lead not found" });
  }

  const rowNumber = targetRow + 1;
  sheet.getRange(rowNumber, statusIndex + 1).setValue(payload.lead.status || "");
  sheet.getRange(rowNumber, notesIndex + 1).setValue(payload.lead.notes || "");
  sheet.getRange(rowNumber, updatedAtIndex + 1).setValue(new Date());
  sheet.getRange(rowNumber, whatsappCountIndex + 1).setValue(Number(payload.lead.whatsappCount || 0));

  updatePipelineSummary();
  return jsonOutput({ ok: true });
}

function setupLeadDesk() {
  const spreadsheet = SpreadsheetApp.getActive();
  const leadsSheet = spreadsheet.getSheetByName(SHEET_NAME);
  if (!leadsSheet) {
    spreadsheet.insertSheet(SHEET_NAME);
  }
  updatePipelineSummary();
}

function updatePipelineSummary() {
  const spreadsheet = SpreadsheetApp.getActive();
  const leadsSheet = spreadsheet.getSheetByName(SHEET_NAME);
  if (!leadsSheet) return;

  const values = leadsSheet.getDataRange().getValues();
  if (!values.length) return;

  const headers = values[0];
  const leads = values
    .slice(1)
    .filter((row) => row.some(Boolean))
    .map((row) => rowToLead(headers, row));

  const summarySheet = getOrCreateSheet(spreadsheet, PIPELINE_SHEET_NAME);
  summarySheet.clear();

  const now = new Date();
  const summary = buildStatusSummary(leads);
  const campaignSummary = buildCampaignSummary(leads);

  summarySheet.getRange(1, 1, 1, 2).setValues([["Pipeline aggiornata", now]]);
  summarySheet.getRange(3, 1, 1, 5).setValues([["Stato", "Lead", "WhatsApp inviati", "Ultimo lead", "Percentuale"]]);

  if (summary.length) {
    summarySheet.getRange(4, 1, summary.length, 5).setValues(summary);
  }

  const campaignStart = summary.length + 6;
  summarySheet.getRange(campaignStart, 1, 1, 4).setValues([["Campagna", "Lead", "Contattati", "Ultimo lead"]]);
  if (campaignSummary.length) {
    summarySheet.getRange(campaignStart + 1, 1, campaignSummary.length, 4).setValues(campaignSummary);
  }

  const totalRows = Math.max(campaignStart + campaignSummary.length, 4 + summary.length);
  summarySheet.getRange(1, 1, totalRows, 5).setWrap(true);
  summarySheet.autoResizeColumns(1, 5);
  summarySheet.getRange(3, 1, 1, 5).setFontWeight("bold");
  summarySheet.getRange(campaignStart, 1, 1, 4).setFontWeight("bold");
}

function buildStatusSummary(leads) {
  const total = leads.length || 1;
  const byStatus = {};

  leads.forEach((lead) => {
    const status = lead.status || "Nuovo";
    if (!byStatus[status]) {
      byStatus[status] = { count: 0, whatsappCount: 0, latest: null };
    }
    byStatus[status].count += 1;
    byStatus[status].whatsappCount += Number(lead.whatsappCount || 0);
    byStatus[status].latest = getLatestDate(byStatus[status].latest, lead.createdAt);
  });

  return Object.keys(byStatus).map((status) => {
    const item = byStatus[status];
    return [status, item.count, item.whatsappCount, item.latest || "", item.count / total];
  });
}

function buildCampaignSummary(leads) {
  const byCampaign = {};

  leads.forEach((lead) => {
    const campaign = lead.campaign || "Senza campagna";
    if (!byCampaign[campaign]) {
      byCampaign[campaign] = { count: 0, contacted: 0, latest: null };
    }
    byCampaign[campaign].count += 1;
    if (String(lead.status || "").toLowerCase().includes("contatt")) {
      byCampaign[campaign].contacted += 1;
    }
    byCampaign[campaign].latest = getLatestDate(byCampaign[campaign].latest, lead.createdAt);
  });

  return Object.keys(byCampaign).map((campaign) => {
    const item = byCampaign[campaign];
    return [campaign, item.count, item.contacted, item.latest || ""];
  });
}

function getLatestDate(current, candidate) {
  if (!candidate) return current;
  if (!current) return candidate;
  return new Date(candidate) > new Date(current) ? candidate : current;
}

function getOrCreateSheet(spreadsheet, name) {
  return spreadsheet.getSheetByName(name) || spreadsheet.insertSheet(name);
}

function rowToLead(headers, row) {
  const lead = {};
  headers.forEach((header, index) => {
    lead[header] = row[index];
  });

  return {
    id: lead.id || lead.ID || lead.lead_id || lead["Lead ID"],
    createdAt: lead.createdAt || lead.created_time || lead["Created Time"] || lead.timestamp,
    name: lead.name || lead.full_name || lead.nome || lead["Full Name"],
    phone: lead.phone || lead.phone_number || lead.telefono || lead["Phone Number"],
    email: lead.email || lead.email_address || lead["Email"],
    campaign: lead.campaign || lead.campaign_name || lead.campagna || lead["Campaign Name"],
    source: lead.source || lead.platform || "Meta Lead Ads",
    city: lead.city || lead.citta || lead["City"],
    interest: lead.interest || lead.form_name || lead.interesse || lead["Form Name"],
    status: lead.status || "Nuovo",
    notes: lead.notes || "",
    updatedAt: lead.updatedAt || "",
    whatsappCount: Number(lead.whatsappCount || 0),
  };
}

function ensureColumn(sheet, headers, name) {
  const existing = headers.indexOf(name);
  if (existing !== -1) return existing;

  const column = headers.length + 1;
  sheet.getRange(1, column).setValue(name);
  headers.push(name);
  return column - 1;
}

function jsonOutput(payload) {
  return ContentService
    .createTextOutput(JSON.stringify(payload))
    .setMimeType(ContentService.MimeType.JSON);
}
